# 自适应MF与线性规模色焦差案例

这是原14片绿光案例的独立优化分支。ADAPTIVE_WORKING.ZMX/MF含15,164行，48次波前查询；ADAPTIVE_FULL_SPAN.ZMX及FULL_SPAN.MF含196,375行，保留完整原审计目标并将51波长的成对LCA上限改为MAXX/MINN跨度。两份文件是同一最终处方，都经过保存、关闭文件和重载数值核对。

原生优化运行两轮，执行74次工作MF评价。从S21半径-0.01%扰动起点优化S21/S24曲率；固定像面，保留其余实际处方。独立最终复核通过原始八绿光波前、51波长LCA、65视场FC及局部极值、一阶、实体、所有15波长的物理通光。最坏波前/相应目标=0.970173205893，LCA约0.582313um，FC约0.535928um。具体定义、各波长与全部余量见INDEPENDENT_FINAL_AUDIT.json。

当前完整域不能宣称数学全局最优；波前误差探针、同时误差良率、安装/热/供应商验收和制造放行未完成。BLUE与790nm只有指定监测角色，不能冒充宽谱复消色差均已通过。制造要求与参考标准以INPUT_PINS所固定原案例规格为准。

## 打开

1. 解压到新目录。运行`python verify_and_prepare_catalogs.py --verify-only`检查全部字节。
2. 使用自己有权访问且SHA256匹配的OHARA原始AGF：`python verify_and_prepare_catalogs.py --ohara-path "D:/private/OHARA.AGF"`。厂商完整目录不随本包公开。
3. 在OpticStudio中将Zemax目录作为项目目录，启用项目内GLASSCAT，打开ADAPTIVE_WORKING.ZMX，需要时载入同名MF。完整审计使用ADAPTIVE_FULL_SPAN.ZMX与FULL_SPAN.MF。保持13个构型与各构型主波长。

固定窗口FIXWIN.AGF随包提供。完整OHARA SHA256为9ad9d23da983ef105ec02dd6c9ad55f124163ad604a074e53f753dc351c49e86。字节校验脚本不代替光学验收。

源代码、重新优化命令和独立算法对照在仓库examples/algorithm-suite-green8。原始ZEMAX_AND_MF.zip未改写。SPAN_PROOF与SPAN_VALIDATION包含成对覆盖证明及三处曲率试探的原生数值对照；RELOAD_VALIDATION为两套交付文件的重载核对。LCA可行集合保持，加权罚函数改变。
